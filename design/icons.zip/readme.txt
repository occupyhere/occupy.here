"BacktoPixel 1.0" icons set by Icojoy.com

Ammount of icons:
75

Colors: 
10+

Icon Sizes:
9x9, 18x18, 28x28

File Types:
.gif (indexed)
.png (RGBA)

Note: These icons are free for use.